﻿using System.Windows.Controls;

namespace AAD.ImmoWin.WpfApp.Views
{
    /// <summary>
    /// Interaction logic for AppartementModuleView.xaml
    /// </summary>
    public partial class AppartementView : UserControl
    {
        public AppartementView()
        {
            InitializeComponent();
        }
    }
}
