﻿public enum KlantLijstStatus
{
	Tonen,
	Toevoegen,
	Wijzigen,
	Verwijderen
}