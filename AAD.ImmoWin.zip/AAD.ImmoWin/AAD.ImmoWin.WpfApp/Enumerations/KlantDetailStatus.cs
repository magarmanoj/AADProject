﻿public enum KlantDetailStatus
{
	Tonen,
	Wijzigen,
	Bewaren, 
	Annuleren
}