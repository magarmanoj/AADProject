﻿public enum DetailStatus
{
	Tonen,
	Wijzigen,
	Bewaren, 
	Annuleren
}