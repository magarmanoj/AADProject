﻿public enum LijstStatus
{
	Tonen,
	Toevoegen,
	Wijzigen,
	Verwijderen
}